package com.inducesmile.androidmultiquiz.helper;

public class Helper {

    public static final String instruction = "The My Life Balance application is an application " +
            "that will help the My Life Balance find out more details of the client and " +
            "personalise a profile of what they are wanting as a result in life coaching and with " +
            "what they will be purchasing on the site. The Application will ask a series of " +
            "questions and you will need to select your best answer."+

    "\n\nMy Life Balance, Step by Step Instructions:"
            +"\n1. When the application starts you will find categories of quiz."
            +"\n2. Select the category."+"\n3. Select you answer to the quiz question,"
            +" Think carefully about your response as you cannot go back."
            +"\n4. Select your overall score to the quiz.";


    public static final String SHARED_PREF = "share_pref";

    public static final String QUIZ_SCORE = "quiz_score";

    public static final String LOGGED_IN = "logged_in";
}
